#pragma once
#include <stdint.h>
#include "skin_assets.h"

// Konfigurace rendereru (žádný float, čistý kontrakt)
struct EyeRenderConfig {
  int baseW = 240;
  int baseH = 240;
  uint16_t keyColor565 = 0xF81F; // default magenta key
  bool swapBytes = true;         // režim B: swapBytes=true
};

void eyeRenderInit(const EyeRenderConfig& cfg);

// načti RAW565 do interních bufferů (base, iris, víčka otevřená)
bool eyeRenderLoadAssets(const SkinAssets& skin);

// vykresli statickou scénu (base + otevřená víčka pokud existují)
void eyeRenderDrawStatic(const SkinAssets& skin);

// vykresli iris patch a poté překryj otevřená víčka (aby iris “zajel pod víčko”)
void eyeRenderDrawIris(int irisX, int irisY, const SkinAssets& skin);

// hook pro RenderApi lids (zatím jen “udržuj otevřená víčka navrchu”)
void eyeRenderDrawLids(uint16_t lidTop, uint16_t lidBot, const SkinAssets& skin);
