#pragma once
#include <stdint.h>
#include <functional>
#include "skin_assets.h"
#include "dirty_rect.h"

namespace RenderApi {

  using LidDrawFn = std::function<void(const SkinAssets& skin,
                                       uint16_t lidTop, uint16_t lidBot,
                                       const DirtyRect& dr)>;

  // drží interně skin pointer + initne render_eye
  void init(const SkinAssets& skin);

  // kreslení
  void drawStatic();
  void drawIris(int irisX, int irisY);

  // víčka (hook)
  void setLidDrawFn(LidDrawFn fn);
  void drawLids(uint16_t lidTop, uint16_t lidBot, const DirtyRect& dr);

} // namespace RenderApi
