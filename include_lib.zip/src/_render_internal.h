#pragma once
#define RENDERER_CAN_DRAW
#include "TftManager.h"
